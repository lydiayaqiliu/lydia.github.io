from typing import Optional
import requests, tempfile, os
from .config import ELEVENLABS_API_KEY, ELEVENLABS_VOICE_ID

def synthesize_tts(text: str, voice_id: Optional[str]=None) -> Optional[str]:
    if not ELEVENLABS_API_KEY:
        return None
    voice = voice_id or ELEVENLABS_VOICE_ID
    url = f"https://api.elevenlabs.io/v1/text-to-speech/{voice}"
    headers = {
        "xi-api-key": ELEVENLABS_API_KEY,
        "accept": "audio/mpeg",
        "Content-Type": "application/json",
    }
    payload = {
        "text": text,
        "model_id": "eleven_monolingual_v1",
        "voice_settings": {"stability": 0.35, "similarity_boost": 0.7}
    }
    try:
        r = requests.post(url, json=payload, headers=headers, timeout=60)
        r.raise_for_status()
        fd, path = tempfile.mkstemp(suffix=".mp3")
        with os.fdopen(fd, "wb") as f:
            f.write(r.content)
        return path
    except Exception:
        return None
