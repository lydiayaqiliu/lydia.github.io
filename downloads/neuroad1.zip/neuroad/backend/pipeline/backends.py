from __future__ import annotations
from typing import List, Dict, Optional, Any, Tuple
import random
import numpy as np
from PIL import Image

def _try_import_diffusers():
    try:
        import torch  # noqa
        from diffusers import StableDiffusionXLImg2ImgPipeline, StableVideoDiffusionPipeline  # noqa
        return True
    except Exception:
        return False

def _torch_device():
    try:
        import torch  # noqa
        return "cuda" if __import__("torch").cuda.is_available() else "cpu"
    except Exception:
        return "cpu"

from .config import (
    SDXL_BASE, SDXL_REFINER, SVD_MODEL, SEED, ASPECT,
    LUMA_API_KEY,
)
from .generate import _apply_grade, _place_text

_rng = random.Random(SEED)

def _calc_size(aspect: str, max_side: int = 1024) -> Tuple[int,int]:
    try:
        a,b = aspect.split(":")
        a,b = int(a), int(b)
        if a >= b:
            w = max_side; h = int(round(max_side * b / a))
        else:
            h = max_side; w = int(round(max_side * a / b))
        w -= w % 8; h -= h % 8
        return w, h
    except Exception:
        return 1024, 1024

class ImageBackend:
    def image_variations(self, image: Image.Image, ideas: List[Dict]) -> List[Image.Image]:
        raise NotImplementedError

class VideoBackend:
    def video_variations(self, frames: List[Image.Image], ideas: List[Dict], fps: int) -> List[List[Image.Image]]:
        raise NotImplementedError

class LocalOpsImageBackend(ImageBackend):
    def image_variations(self, image: Image.Image, ideas: List[Dict]) -> List[Image.Image]:
        outs=[]
        for idea in ideas:
            im = image
            tags = " ".join(idea.get("style_tags", [])).lower()
            if "retro" in tags: im = _apply_grade(im, "retro")
            if "minimal" in tags: im = _apply_grade(im, "minimal")
            if "neon" in tags or "punchy" in tags: im = _apply_grade(im, "punchy")
            if "forest" in idea.get("scene","").lower(): im = _apply_grade(im, "cinematic")
            copy_txt = idea.get("copy", "")
            if copy_txt:
                pos = "top" if len(copy_txt) > 20 else "bottom"
                im = _place_text(im, copy_txt, position=pos)
            outs.append(im)
        return outs

class LocalOpsVideoBackend(VideoBackend):
    def video_variations(self, frames: List[Image.Image], ideas: List[Dict], fps: int) -> List[List[Image.Image]]:
        # simple simulated motion using earlier helper via generate.generate_video_variations with text prompts
        from .generate import generate_video_variations as _sim_generate
        idea_texts = [f"{i.get('title','')} {i.get('style_tags',[])} {i.get('copy','')}" for i in ideas]
        from .generate import generate_video_variations as _old
        # To avoid recursion, re-implement a minimal motion (zoom + grade + text)
        clips: List[List[Image.Image]] = []
        total = len(frames)
        for k, idea in enumerate(ideas):
            out=[]
            tags = " ".join(idea.get("style_tags", [])).lower()
            copy_txt = idea.get("copy","").strip()
            for idx, fr in enumerate(frames):
                im = fr
                if "retro" in tags: im = _apply_grade(im, "retro")
                if "minimal" in tags: im = _apply_grade(im, "minimal")
                if "neon" in tags or "punchy" in tags: im = _apply_grade(im, "punchy")
                # simple zoom
                z = 1.0 + 0.05 * np.sin(2*np.pi*idx/max(1,total))
                w,h = im.size
                cw,ch = int(w/z), int(h/z)
                x0,y0 = (w-cw)//2, (h-ch)//2
                im = im.crop((x0,y0,x0+cw,y0+ch)).resize((w,h), Image.LANCZOS)
                if copy_txt:
                    im = _place_text(im, copy_txt, position="bottom")
                out.append(im)
            clips.append(out)
        return clips

class SDXLImageBackend(ImageBackend):
    def __init__(self):
        self.ready = False
        if not _try_import_diffusers(): return
        try:
            import torch
            from diffusers import StableDiffusionXLImg2ImgPipeline
            device = _torch_device()
            self.pipe = StableDiffusionXLImg2ImgPipeline.from_pretrained(
                SDXL_BASE, torch_dtype=torch.float16 if device=="cuda" else torch.float32, use_safetensors=True
            ).to(device)
            self.ready = True
        except Exception:
            self.ready = False

    def image_variations(self, image: Image.Image, ideas: List[Dict]) -> List[Image.Image]:
        if not self.ready:
            return LocalOpsImageBackend().image_variations(image, ideas)
        import torch
        device = _torch_device()
        outs=[]
        for idx, idea in enumerate(ideas):
            prompt = idea.get("prompt","")
            negative = idea.get("negative","")
            guidance = float(idea.get("guidance", 6.5))
            strength = float(idea.get("strength", 0.5))
            w,h = _calc_size(idea.get("aspect","4:5"), 1024)
            generator = torch.Generator(device=device).manual_seed(SEED + idx)
            init = image.resize((w,h), Image.LANCZOS)
            res = self.pipe(
                prompt=prompt,
                negative_prompt=negative or None,
                image=init,
                strength=max(0.2, min(0.85, strength)),
                guidance_scale=max(3.0, min(12.0, guidance)),
                num_inference_steps=30,
                generator=generator,
            )
            im = res.images[0]
            copy_txt = idea.get("copy","").strip()
            if copy_txt:
                im = _place_text(im, copy_txt, position="bottom")
            outs.append(im)
        return outs

class SVDVideoBackend(VideoBackend):
    def __init__(self):
        self.ready = False
        if not _try_import_diffusers(): return
        try:
            import torch
            from diffusers import StableVideoDiffusionPipeline
            device = _torch_device()
            self.pipe = StableVideoDiffusionPipeline.from_pretrained(
                SVD_MODEL, torch_dtype=torch.float16 if device=="cuda" else torch.float32
            ).to(device)
            self.ready = True
        except Exception:
            self.ready = False

    def video_variations(self, frames: List[Image.Image], ideas: List[Dict], fps: int) -> List[List[Image.Image]]:
        if not self.ready:
            return LocalOpsVideoBackend().video_variations(frames, ideas, fps)
        import torch
        device = _torch_device()
        clips: List[List[Image.Image]] = []
        ref = frames[len(frames)//2] if frames else None
        if ref is None:
            return LocalOpsVideoBackend().video_variations(frames, ideas, fps)
        for idx, idea in enumerate(ideas):
            w,h = _calc_size(idea.get("aspect","4:5"), 768)
            init = ref.resize((w,h), Image.LANCZOS)
            strength = float(idea.get("strength", 0.6))
            generator = torch.Generator(device=device).manual_seed(SEED + idx)
            num_frames = max(12, min(48, int(fps*2)))
            res = self.pipe(
                image=init,
                decode_chunk_size=4,
                motion_bucket_id=127,
                noise_aug_strength=strength,
                num_frames=num_frames,
                generator=generator,
            )
            vid = res.frames[0]
            clip: List[Image.Image] = []
            copy_txt = idea.get("copy","").strip()
            for arr in vid:
                im = Image.fromarray(arr)
                if copy_txt:
                    im = _place_text(im, copy_txt, position="bottom")
                clip.append(im)
            clips.append(clip)
        return clips

class LumaVideoBackend(VideoBackend):
    def __init__(self):
        self.ready = bool(LUMA_API_KEY)

    def video_variations(self, frames: List[Image.Image], ideas: List[Dict], fps: int) -> List[List[Image.Image]]:
        if not self.ready:
            return LocalOpsVideoBackend().video_variations(frames, ideas, fps)
        # Use lumaapi client to submit an input image sequence as a small video (reference),
        # but since this runtime may not have lumaapi installed, we keep this optional
        try:
            from lumaapi import LumaClient
        except Exception:
            return LocalOpsVideoBackend().video_variations(frames, ideas, fps)

        import tempfile, os, cv2, numpy as np, time, requests
        client = LumaClient(LUMA_API_KEY)
        clips: List[List[Image.Image]] = []
        # Create a small reference mp4 per idea and submit
        for idx, idea in enumerate(ideas):
            with tempfile.NamedTemporaryFile(suffix=".mp4", delete=False) as tf:
                path = tf.name
            try:
                # encode a short reference clip from frames
                if not frames:
                    clips.append([]); continue
                h, w = frames[0].size[1], frames[0].size[0]
                vw = cv2.VideoWriter(path, cv2.VideoWriter_fourcc(*"mp4v"), max(12, fps//2), (w, h))
                for i, fr in enumerate(frames[:min(len(frames), fps*2)]):
                    arr = cv2.cvtColor(np.array(fr), cv2.COLOR_RGB2BGR)
                    vw.write(arr)
                vw.release()
                title = idea.get("title","variation")
                slug = client.submit(path, title)
                # poll until finished (with timeout)
                deadline = time.time() + 600
                art_url = None
                while time.time() < deadline:
                    st = client.status(slug)
                    run = getattr(st, "latest_run", None)
                    if run and getattr(run, "status", None).name == "FINISHED":
                        arts = getattr(run, "artifacts", [])
                        # pick first mp4 url
                        for a in arts:
                            if a.get("type","").lower() in ("video","mp4","mp4_video") or a.get("url","").endswith(".mp4"):
                                art_url = a.get("url")
                                break
                        break
                    if run and getattr(run, "status", None).name == "FAILED":
                        break
                    time.sleep(3.0)
                if not art_url:
                    # fallback
                    clips.append(LocalOpsVideoBackend().video_variations(frames, [idea], fps)[0])
                    continue
                # download video and decode to frames
                import requests, tempfile
                r = requests.get(art_url, timeout=60)
                r.raise_for_status()
                with tempfile.NamedTemporaryFile(suffix=".mp4") as f:
                    f.write(r.content); f.flush()
                    cap = cv2.VideoCapture(f.name)
                    out_frames: List[Image.Image] = []
                    ok, frame = cap.read()
                    while ok:
                        fr = Image.fromarray(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
                        out_frames.append(fr)
                        ok, frame = cap.read()
                    cap.release()
                clips.append(out_frames)
            finally:
                try: os.remove(path)
                except Exception: pass
        return clips

def get_image_backend(name: str) -> ImageBackend:
    if name == "sdxl":
        b = SDXLImageBackend()
        if b.ready:
            return b
    return LocalOpsImageBackend()

def get_video_backend(name: str) -> VideoBackend:
    if name == "svd":
        b = SVDVideoBackend()
        if b.ready:
            return b
    if name == "luma":
        b = LumaVideoBackend()
        if b.ready:
            return b
    return LocalOpsVideoBackend()
