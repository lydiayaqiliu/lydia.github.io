let devToolsVisible = false;
let gazeData = [];
let heatmapCanvas;
let heatmapVisible = false;
let mediaRecorder;
let recordedChunks = [];
let currentBox = null;
let galleryVisible = false;
let apieceoftext = 'From 0-17s, user eye gaze is scattered across the producer’s hands, the blender, and the Obvi tub. At 18s, the pouring of pink coconut water catches the user’s eye and subtly directs the attention towards the pink Obvi product (i.e. color priming). At 37s, the visual connection strengthens, with more frequent glances towards the Obvi container. From 50s on, the user begins to look directly at the product and sometimes at the pink drink in the glass. This ad shows an effective, gradual build of brand recognition through color and gaze behavior. \n \n User gaze on scale: in internal testing, some viewers show more frequent eye gaze at the coconut water than the Obvi product. However, once they learnt that Obvi is concerned with nutrition and weight loss, they suddenly understand the ad. To strengthen this connection, adding a closing line such as “Obvi – your nutrition / weight loss companion” may help clarify the product’s purpose in this ad. '
let url = 'https://raw.githubusercontent.com/juriosity/neuroad/refs/heads/main/pictures/User%20gaze%20at%20the%20Obvi%20(final%20focus%20of%20the%20user%20has%20changed).jpg?token=GHSAT0AAAAAADFY36AOVQUKESP2KI6BQ4ZS2CXKQQQ'

const imageList = [
    {
    url: './images/user gaze at the lid of Obvi.jpg',
    caption: 'The user gazed at the lid of the Obvi.'
  },
  {
    url: './images/user gaze at the blender.jpg',
    caption: 'The user gazed at the blender.'
  },
  {
    url: './images/user gaze at the coconut water.jpg',
    caption: 'The user gazed at the coconut water.'
  },
  {
    url: './images/User gaze at the Obvi (final focus of the user has changed).jpg',
    caption: 'The user gazed at the Obvi. The fianl focus of the user has changed.'
  },
];




function toggleDevTools() {
    devToolsVisible = !devToolsVisible;
    // Toggle real-time data display
    document.getElementById("GazeData").style.display = devToolsVisible ? "block" : "none";
    document.getElementById("HeadPhoseData").style.display = devToolsVisible ? "block" : "none";
    document.getElementById("HeadRotData").style.display = devToolsVisible ? "block" : "none";
    // Optionally hide the gaze circle if dev tools are off
    const gaze = document.getElementById("gaze");
    if (!devToolsVisible) {
        gaze.style.display = "none";
    }
    // Update button text
    const btn = document.getElementById("devToolsToggle");
    if (btn) btn.textContent = devToolsVisible ? "Hide Dev Tools" : "Show Dev Tools";
}

function updateGazeSummary() {
    if (gazeData.length === 0) return;
    let xCount = {};
    let yCount = {};
    gazeData.forEach(data => {
        xCount[data.x] = (xCount[data.x] || 0) + 1;
        yCount[data.y] = (yCount[data.y] || 0) + 1;
    });
    let mostFrequentX = Object.keys(xCount).reduce((a, b) => xCount[a] > xCount[b] ? a : b);
    let mostFrequentY = Object.keys(yCount).reduce((a, b) => yCount[a] > yCount[b] ? a : b);
    let summaryDiv = document.getElementById('GazeSummary');
    if (!summaryDiv) {
        summaryDiv = document.createElement('div');
        summaryDiv.id = 'GazeSummary';
        summaryDiv.style.position = 'fixed';
        summaryDiv.style.bottom = '10px';
        summaryDiv.style.right = '10px';
        summaryDiv.style.background = 'rgba(0,0,0,0.7)';
        summaryDiv.style.color = 'white';
        summaryDiv.style.padding = '6px 12px';
        summaryDiv.style.borderRadius = '6px';
        summaryDiv.style.zIndex = 1000000;
        document.body.appendChild(summaryDiv);
    }
    summaryDiv.textContent = `Most frequent gaze: X=${mostFrequentX}, Y=${mostFrequentY}`;
}

function initHeatmap() {
    heatmapCanvas = document.createElement('canvas');
    heatmapCanvas.id = 'heatmapCanvas';
    heatmapCanvas.style.position = 'fixed';
    heatmapCanvas.style.top = '0';
    heatmapCanvas.style.left = '0';
    heatmapCanvas.style.width = '100%';
    heatmapCanvas.style.height = '100%';
    heatmapCanvas.style.pointerEvents = 'none';
    heatmapCanvas.style.zIndex = 999999;
    // Set canvas size to match window size
    heatmapCanvas.width = window.innerWidth;
    heatmapCanvas.height = window.innerHeight;
    document.body.appendChild(heatmapCanvas);
}

function drawHeatmap(x, y) {
    const ctx = heatmapCanvas.getContext('2d');
    // Clear the previous frame
    ctx.clearRect(0, 0, heatmapCanvas.width, heatmapCanvas.height);
    
    // Create a more visible heatmap effect
    const gradient = ctx.createRadialGradient(x, y, 0, x, y, 100);
    gradient.addColorStop(0, 'rgba(23, 76, 140, 0.8)');  // More opaque center
    gradient.addColorStop(0.5, 'rgba(51, 85, 165, 0.47)'); // Semi-transparent middle
    gradient.addColorStop(1, 'rgba(177, 177, 219, 0.32)');    // Transparent edge
    
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, heatmapCanvas.width, heatmapCanvas.height);
}

function toggleHeatmap() {
    heatmapVisible = !heatmapVisible;
    const heatmapCanvas = document.getElementById('heatmapCanvas');
    if (heatmapCanvas) {
        heatmapCanvas.style.display = heatmapVisible ? 'block' : 'none';
    }
    // Update button text
    const btn = document.getElementById('heatmapToggle');
    if (btn) btn.textContent = heatmapVisible ? 'Hide Heatmap' : 'Show Heatmap';
}

function PlotGaze(GazeData) {
    /*
    GazeData.state // 0: valid gaze data; -1 : face tracking lost, 1 : gaze uncalibrated
    GazeData.docX // gaze x in document coordinates
    GazeData.docY // gaze y in document cordinates
    GazeData.time // timestamp
    */
    if (devToolsVisible) {
        GazeData.GazeX && (document.getElementById("GazeData").innerHTML =
            `GazeX: ${GazeData.GazeX}  GazeY: ${GazeData.GazeY}`);
        document.getElementById("HeadPhoseData").innerHTML =
            `HeadX: ${GazeData.HeadX}  HeadY: ${GazeData.HeadY}  HeadZ: ${GazeData.HeadZ}`;
        document.getElementById("HeadRotData").innerHTML =
            `Yaw: ${GazeData.HeadYaw}  Pitch: ${GazeData.HeadPitch}  Roll: ${GazeData.HeadRoll}`;
    }

    /* ---------- 2) Heatmap + summary ---------- */
    if (GazeData.state === 0) {                    // only if gaze is valid
        // heat-map spot
        if (devToolsVisible && heatmapVisible) {
            drawHeatmap(GazeData.docX, GazeData.docY);
        }
        // add to running history for “most frequent gaze”
        gazeData.push({ x: GazeData.GazeX, y: GazeData.GazeY });
        updateGazeSummary();
    }

    /* ---------- 3) Red “gaze-dot” overlay ---------- */
    const gazeDot = document.getElementById("gaze");
    if (gazeDot) {
        // centre the dot on the co-ordinates
        const x = GazeData.docX - gazeDot.clientWidth  / 2;
        const y = GazeData.docY - gazeDot.clientHeight / 2;
        gazeDot.style.left = `${x}px`;
        gazeDot.style.top  = `${y}px`;

        if (GazeData.state === 0 && devToolsVisible) {
            gazeDot.style.display = 'block';       // show while valid & dev-tools on
        } else {
            gazeDot.style.display = 'none';        // hide otherwise
        }
    }
}

// function showMostFrequentDot() {
//     if (gazeData.length === 0) return;
//     let xCount = {};
//     let yCount = {};
//     gazeData.forEach(data => {
//         xCount[data.x] = (xCount[data.x] || 0) + 1;
//         yCount[data.y] = (yCount[data.y] || 0) + 1;
//     });
//     let mostFrequentX = Object.keys(xCount).reduce((a, b) => xCount[a] > xCount[b] ? a : b);
//     let mostFrequentY = Object.keys(yCount).reduce((a, b) => yCount[a] > yCount[b] ? a : b);
//     // Clear gaze and color data after showing the dot
//     gazeData = [];
//     colorData = {};
// }

function handleStopClick () {

    GazeCloudAPI.StopEyeTracking();  // the original function

    const btn1 = document.getElementById('mktBtn');           

    if (btn1) {
        btn1.style.display = 'inline-block'; 
    }

    const btn2 = document.getElementById('hmBtn');           

    if (btn2) {
        btn2.style.display = 'inline-block'; 
    }
}

function showImage(imageObj) {
  let gallery = document.getElementById('imageGallery');
  if (!gallery) {
    gallery = document.createElement('div');
    gallery.id = 'imageGallery';
    Object.assign(gallery.style, {
      position: 'fixed',
      bottom: '90px',
      right:  '300px',
      width:  '400px',
      height: '500px',
      overflowY: 'auto',
      padding: '8px',
      background: '#fff',
      border: '1px solid #ccc',
      boxShadow: '0 2px 8px rgba(0,0,0,0.2)',
      zIndex: 1000
    });
    document.body.appendChild(gallery);
  }

  const container = document.createElement('div');
  container.style.marginBottom = '20px';

  const img = document.createElement('img');
  img.src = imageObj.url;
  img.alt = imageObj.caption;
  img.style.width = '100%';
  img.style.display = 'block';

  const caption = document.createElement('p');
  caption.textContent = imageObj.caption;
  caption.style.fontSize = '14px';
  caption.style.marginTop = '4px';
  caption.style.color = '#555';

  container.appendChild(img);
  container.appendChild(caption);
  gallery.appendChild(container);
}


function loadAllImages() {
  imageList.forEach(showImage);
}


function toggleGallery() {
  if (!galleryVisible) {
    // 1st click – create & fill the gallery
    loadAllImages();          // calls imageList.forEach(showImage)
    galleryVisible = true;
  } else {
    // 2nd click – remove the gallery
    const g = document.getElementById('imageGallery');
    if (g) g.remove();
    galleryVisible = false;
  }
}



function showTextBox(text) {
    if (currentBox) {
        // remove the existing textbox
        currentBox.parentNode.removeChild(currentBox);  // (or currentBox.remove() in modern browsers)
        currentBox = null;                              // remember: no textbox on screen now
    } else {
        // create a new textbox
        const box = document.createElement('textarea');
        box.value    = text;
        box.readOnly = true;
        box.rows     = 15;
        box.cols     = 40;

        box.style.position = 'fixed';     // 'fixed' keeps it pinned to the viewport
        box.style.bottom = '230px';        // distance from bottom
        box.style.right = '700px';         // distance from right
        box.style.margin   = '-20px';
        box.style.padding = '12px'

        document.body.appendChild(box);
        currentBox = box;                               // store reference for the next toggle
    }
  }

  function starteyetraker() {
    GazeCloudAPI.StartEyeTracking();
}


function startRecording() {
    navigator.mediaDevices.getDisplayMedia({ video: true })
        .then(stream => {
            mediaRecorder = new MediaRecorder(stream, {
                mimeType: 'video/webm;codecs=vp9',
                videoBitsPerSecond: 2500000 // 2.5 Mbps
            });
            
            mediaRecorder.ondataavailable = event => {
                if (event.data.size > 0) {
                    recordedChunks.push(event.data);
                }
            };
            
            mediaRecorder.onstop = () => {
                const blob = new Blob(recordedChunks, { type: 'video/webm' });
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `heatmap-recording-${new Date().toISOString()}.webm`;
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                URL.revokeObjectURL(url);
                recordedChunks = [];
                
                // Stop all tracks in the stream
                stream.getTracks().forEach(track => track.stop());
            };
            
            // Start recording with 1-second chunks
            mediaRecorder.start(1000);
            document.getElementById('recordBtn').textContent = 'Stop Recording';
        })
        .catch(err => console.error('Error accessing media devices:', err));
}

function stopRecording() {
    if (mediaRecorder && mediaRecorder.state === 'recording') {
        mediaRecorder.stop();
        document.getElementById('recordBtn').textContent = 'Start Recording';
    }
}

function toggleRecording() {
    if (mediaRecorder && mediaRecorder.state === 'recording') {
        stopRecording();
    } else {
        startRecording();
    }
}

// Add window resize handler to update canvas size
window.addEventListener('resize', function() {
    if (heatmapCanvas) {
        heatmapCanvas.width = window.innerWidth;
        heatmapCanvas.height = window.innerHeight;
    }
});

window.addEventListener("load", function() {
    // Hide dev tools by default
    document.getElementById("GazeData").style.display = "none";
    document.getElementById("HeadPhoseData").style.display = "none";
    document.getElementById("HeadRotData").style.display = "none";
    initHeatmap();
    GazeCloudAPI.OnCalibrationComplete = function(){ 
        console.log('gaze Calibration Complete');
        startRecording();
    }
    GazeCloudAPI.OnCamDenied = function(){ console.log('camera access denied') }
    GazeCloudAPI.OnError = function(msg){ console.log('err: ' + msg) }
    GazeCloudAPI.UseClickRecalibration = true;
    GazeCloudAPI.OnResult = PlotGaze;
    // Add event listener for the Stop button
    document.getElementById('stopBtn').addEventListener('click', showMostFrequentDot);
    // Add event listener for the Heatmap toggle button
    document.getElementById('heatmapToggle').addEventListener('click', toggleHeatmap);
    // Add event listener for the Record button
    document.getElementById('recordBtn').addEventListener('click', toggleRecording);
});