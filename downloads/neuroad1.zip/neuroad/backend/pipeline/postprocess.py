from typing import Any, List, Tuple, Optional
from pathlib import Path
import numpy as np
import cv2
from PIL import Image

from .config import OUTPUT_DIR, IMG_EXT, VID_EXT, FPS
from .ffmpeg_utils import encode_with_ffmpeg, encode_with_opencv

def finalize_images(raw_images: List[Image.Image], basename: str = "image_var") -> Tuple[List[bytes], List[str]]:
    out_bytes, out_paths = [], []
    for i, im in enumerate(raw_images):
        p: Path = OUTPUT_DIR / f"{basename}_{i+1}{IMG_EXT}"
        if IMG_EXT.lower() in (".jpg", ".jpeg"):
            im.save(p, format="JPEG", quality=92)
        else:
            im.save(p, format="PNG", optimize=True)
        out_paths.append(str(p))
        with open(p, "rb") as f:
            out_bytes.append(f.read())
    return out_bytes, out_paths

def stitch_single_video(frames: List[Image.Image], fps: int, path: Path, audio_path: Optional[str]=None) -> None:
    ok = encode_with_ffmpeg(frames, fps, str(path), audio_path=audio_path)
    if not ok:
        # fallback without audio
        encode_with_opencv(frames, fps, str(path))

def stitch_videos(raw_clips: List[List[Image.Image]], fps: int = FPS, basename: str = "video_var",
                  audio_paths: Optional[List[Optional[str]]] = None) -> Tuple[List[bytes], List[str]]:
    out_bytes, out_paths = [], []
    for idx, clip in enumerate(raw_clips):
        if not clip: 
            continue
        path: Path = OUTPUT_DIR / f"{basename}_{idx+1}{VID_EXT}"
        audio = audio_paths[idx] if audio_paths and idx < len(audio_paths) else None
        stitch_single_video(clip, fps, path, audio_path=audio)
        out_paths.append(str(path))
        with open(path, "rb") as f:
            out_bytes.append(f.read())
    return out_bytes, out_paths
