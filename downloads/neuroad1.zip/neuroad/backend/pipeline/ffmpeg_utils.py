from typing import List, Optional
from pathlib import Path
import subprocess, tempfile, os
import cv2, numpy as np
from PIL import Image
from .config import FPS
from .utils import which_ffmpeg

def encode_with_ffmpeg(frames: List[Image.Image], fps: int, out_path: str, audio_path: Optional[str]=None) -> bool:
    ff = which_ffmpeg()
    if not ff:
        return False
    # Write frames to a temp dir as PNGs
    with tempfile.TemporaryDirectory() as td:
        temp_dir = Path(td)
        for i, fr in enumerate(frames):
            p = temp_dir / f"frame_{i:05d}.png"
            fr.save(p, "PNG")
        cmd = [ff, "-y", "-framerate", str(fps), "-i", str(temp_dir / "frame_%05d.png")]
        if audio_path:
            cmd += ["-i", audio_path, "-shortest"]
        cmd += [
            "-pix_fmt", "yuv420p",
            "-c:v", "libx264",
            "-crf", "21",
            "-preset", "medium",
        ]
        if audio_path:
            cmd += ["-c:a", "aac", "-b:a", "128k"]
        cmd += [out_path]
        return subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE).returncode == 0

def encode_with_opencv(frames: List[Image.Image], fps: int, out_path: str) -> bool:
    if not frames:
        return False
    w, h = frames[0].size
    vw = cv2.VideoWriter(out_path, cv2.VideoWriter_fourcc(*"mp4v"), fps, (w, h))
    if not vw.isOpened():
        return False
    for fr in frames:
        arr = cv2.cvtColor(np.array(fr), cv2.COLOR_RGB2BGR)
        vw.write(arr)
    vw.release()
    return True
