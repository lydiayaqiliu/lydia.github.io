import { useState } from 'react'
import './App.css'
import Navbar from './components/Navbar'
import Homepage from './components/Homepage'
import Profile from './components/Profile'
import Reports from './components/Reports'
import Settings from './components/Settings'
import Ads from './components/Ads'
import Studio from './components/Studio'

function App() {
  const [currentPage, setCurrentPage] = useState('home')
  const [isNavbarCollapsed, setIsNavbarCollapsed] = useState(false)

  const renderPage = () => {
    switch(currentPage) {
      case 'home':
        return <Homepage setCurrentPage={setCurrentPage} />
      case 'profile':
        return <Profile />
      case 'reports':
        return <Reports />
      case 'settings':
        return <Settings />
      case 'ads':
        return <Ads />
      case 'studio':
        return <Studio />
      default:
        return <Homepage setCurrentPage={setCurrentPage} />
    }
  }

  return (
    <div className="App">
      {/* Top Header */}
      <header className="top-header">
        <h1>NeuroAd</h1>
        <p>Welcome, USER from COMPANY</p>
      </header>

      <Navbar
        currentPage={currentPage}
        setCurrentPage={setCurrentPage}
        isCollapsed={isNavbarCollapsed}
        setIsCollapsed={setIsNavbarCollapsed}
      />
      <main className={`main-content ${isNavbarCollapsed ? 'expanded' : ''}`}>
        {renderPage()}
      </main>
    </div>
  )
}

export default App
