function Ads() {
  // Sample ads data
  const adsData = [
    { id: 1, name: "Summer Campaign 2024", videoDuration: "0:30", variations: 3, status: "Running" },
    { id: 2, name: "Product Launch Video", videoDuration: "1:15", variations: 5, status: "Paused" },
    { id: 3, name: "Holiday Special Offer", videoDuration: "0:45", variations: 2, status: "Scheduled" },
    { id: 4, name: "Brand Awareness Campaign", videoDuration: "0:60", variations: 4, status: "Running" },
    { id: 5, name: "Retargeting Campaign", videoDuration: "0:20", variations: 1, status: "Draft" },
    { id: 6, name: "Mobile App Promotion", videoDuration: "0:35", variations: 3, status: "Running" },
    { id: 7, name: "Seasonal Collection", videoDuration: "0:50", variations: 6, status: "Paused" }
  ];

  const handleSeeMore = (adId, adName) => {
    console.log(`Viewing details for ${adName} (ID: ${adId})`);
  };

  return (
    <div style={{ padding: '0', maxWidth: '1000px', margin: '0 auto' }}>
      <h1 style={{
        marginBottom: '8px',
        color: '#1a1a1a',
        fontSize: '28px',
        fontWeight: '600',
        letterSpacing: '-0.025em'
      }}>
        Advertisements
      </h1>
      <p style={{
        color: '#6b7280',
        marginBottom: '32px',
        fontSize: '16px',
        fontWeight: '400',
        lineHeight: '1.5'
      }}>
        Manage your advertising campaigns and creative content.
      </p>

      <div style={{
        marginTop: '0',
        backgroundColor: '#ffffff',
        border: '1px solid #e5e7eb',
        borderRadius: '12px',
        overflow: 'hidden',
        boxShadow: '0 1px 3px rgba(0,0,0,0.05)'
      }}>
        {/* Table Header */}
        <div style={{
          display: 'grid',
          gridTemplateColumns: '1fr 120px 100px 100px',
          gap: '0',
          backgroundColor: '#f9fafb',
          borderBottom: '1px solid #e5e7eb',
          fontWeight: '600',
          fontSize: '14px',
          color: '#374151',
          letterSpacing: '-0.01em'
        }}>
          <div style={{ padding: '16px 20px', borderRight: '1px solid #e5e7eb' }}>Name</div>
          <div style={{ padding: '16px 20px', borderRight: '1px solid #e5e7eb' }}>Video Duration</div>
          <div style={{ padding: '16px 20px', borderRight: '1px solid #e5e7eb' }}>Variations</div>
          <div style={{ padding: '16px 20px' }}>Action</div>
        </div>

        {/* Table Rows */}
        {adsData.map((ad, index) => (
          <div
            key={ad.id}
            style={{
              display: 'grid',
              gridTemplateColumns: '1fr 120px 100px 100px',
              gap: '0',
              backgroundColor: index % 2 === 0 ? '#ffffff' : '#fafafa',
              borderBottom: index < adsData.length - 1 ? '1px solid #f3f4f6' : 'none',
              cursor: 'pointer',
              transition: 'background-color 0.15s ease'
            }}
            onMouseEnter={(e) => e.target.style.backgroundColor = '#f3f4f6'}
            onMouseLeave={(e) => e.target.style.backgroundColor = index % 2 === 0 ? '#ffffff' : '#fafafa'}
          >
            <div style={{
              padding: '16px 20px',
              borderRight: '1px solid #f3f4f6',
              display: 'flex',
              alignItems: 'center',
              fontSize: '14px'
            }}>
              <div style={{
                width: '8px',
                height: '8px',
                borderRadius: '50%',
                backgroundColor: ad.status === 'Running' ? '#10b981' :
                                ad.status === 'Paused' ? '#f59e0b' :
                                ad.status === 'Scheduled' ? '#3b82f6' : '#6b7280',
                marginRight: '12px'
              }}></div>
              <span style={{
                fontWeight: '500',
                color: '#1a1a1a',
                letterSpacing: '-0.01em'
              }}>
                {ad.name}
              </span>
            </div>
            <div style={{
              padding: '16px 20px',
              borderRight: '1px solid #f3f4f6',
              fontSize: '14px',
              color: '#6b7280',
              fontFamily: 'ui-monospace, SFMono-Regular, "SF Mono", Consolas, "Liberation Mono", Menlo, monospace',
              fontWeight: '500'
            }}>
              {ad.videoDuration}
            </div>
            <div style={{
              padding: '16px 20px',
              borderRight: '1px solid #f3f4f6',
              fontSize: '14px',
              color: '#6b7280',
              textAlign: 'center',
              fontWeight: '500'
            }}>
              {ad.variations}
            </div>
            <div style={{
              padding: '12px 20px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center'
            }}>
              <button
                onClick={() => handleSeeMore(ad.id, ad.name)}
                style={{
                  backgroundColor: '#1a1a1a',
                  color: 'white',
                  border: 'none',
                  borderRadius: '6px',
                  padding: '8px 16px',
                  fontSize: '12px',
                  fontWeight: '500',
                  cursor: 'pointer',
                  transition: 'all 0.15s ease',
                  letterSpacing: '-0.01em'
                }}
                onMouseEnter={(e) => {
                  e.target.style.backgroundColor = '#2a2a2a';
                  e.target.style.transform = 'translateY(-1px)';
                }}
                onMouseLeave={(e) => {
                  e.target.style.backgroundColor = '#1a1a1a';
                  e.target.style.transform = 'translateY(0)';
                }}
              >
                See More
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Summary Stats */}
      <div style={{
        marginTop: '24px',
        display: 'flex',
        gap: '24px',
        fontSize: '14px',
        color: '#6b7280',
        fontWeight: '500'
      }}>
        <span>{adsData.length} total ads</span>
        <span>{adsData.filter(ad => ad.status === 'Running').length} running</span>
        <span>{adsData.filter(ad => ad.status === 'Paused').length} paused</span>
        <span>{adsData.filter(ad => ad.status === 'Scheduled').length} scheduled</span>
      </div>
    </div>
  );
}

export default Ads; 