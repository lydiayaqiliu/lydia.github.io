


function Navbar({ currentPage, setCurrentPage, isCollapsed, setIsCollapsed }) {
  // SVG Icon Components
  const DashboardIcon = ({ isActive }) => (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M3 3h8v8H3V3zm10 0h8v8h-8V3zM3 13h8v8H3v-8zm10 0h8v8h-8v-8z" fill={isActive ? '#1a1a1a' : '#6b7280'}/>
    </svg>
  );

  const AdsIcon = ({ isActive }) => (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M12 2L2 7v10c0 5.55 3.84 9.74 9 11 5.16-1.26 9-5.45 9-11V7l-10-5z" fill={isActive ? '#1a1a1a' : '#6b7280'}/>
    </svg>
  );

  const StudioIcon = ({ isActive }) => (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M8 5v14l11-7z" fill={isActive ? '#1a1a1a' : '#6b7280'}/>
      <circle cx="5" cy="12" r="3" fill={isActive ? '#1a1a1a' : '#6b7280'}/>
    </svg>
  );

  const ReportsIcon = ({ isActive }) => (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" fill={isActive ? '#1a1a1a' : '#6b7280'}/>
      <path d="m14 2 6 6" stroke={isActive ? '#ffffff' : '#fafafa'} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
      <path d="M16 13H8" stroke={isActive ? '#ffffff' : '#fafafa'} strokeWidth="2" strokeLinecap="round"/>
      <path d="M16 17H8" stroke={isActive ? '#ffffff' : '#fafafa'} strokeWidth="2" strokeLinecap="round"/>
      <path d="M10 9H8" stroke={isActive ? '#ffffff' : '#fafafa'} strokeWidth="2" strokeLinecap="round"/>
    </svg>
  );

  const ProfileIcon = ({ isActive }) => (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z" fill={isActive ? '#1a1a1a' : '#6b7280'}/>
    </svg>
  );

  const SettingsIcon = ({ isActive }) => (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6z" fill={isActive ? '#1a1a1a' : '#6b7280'}/>
      <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z" fill={isActive ? '#1a1a1a' : '#6b7280'}/>
    </svg>
  );

  const MenuIcon = () => (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M3 12h18M3 6h18M3 18h18" stroke="#6b7280" strokeWidth="2" strokeLinecap="round"/>
    </svg>
  );

  const topNavItems = [
    { id: 'home', label: 'Dashboard', icon: DashboardIcon },
    { id: 'ads', label: 'Advertisements', icon: AdsIcon },
    { id: 'studio', label: 'Studio', icon: StudioIcon },
    { id: 'reports', label: 'Reports', icon: ReportsIcon }
  ];

  const bottomNavItems = [
    { id: 'profile', label: 'Profile', icon: ProfileIcon },
    { id: 'settings', label: 'Settings', icon: SettingsIcon }
  ];

  const renderNavButton = (item) => {
    const IconComponent = item.icon;
    return (
      <li key={item.id} style={{ marginBottom: '4px' }}>
        <button
          onClick={() => setCurrentPage(item.id)}
          title={isCollapsed ? item.label : ''}
          style={{
            background: currentPage === item.id ? '#f3f4f6' : 'transparent',
            border: 'none',
            color: currentPage === item.id ? '#1a1a1a' : '#6b7280',
            padding: isCollapsed ? '12px' : '12px 16px',
            borderRadius: '8px',
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            justifyContent: isCollapsed ? 'center' : 'flex-start',
            gap: isCollapsed ? '0' : '12px',
            width: '100%',
            textAlign: 'left',
            fontSize: '14px',
            fontWeight: currentPage === item.id ? '500' : '400',
            transition: 'all 0.15s ease',
            letterSpacing: '-0.01em',
            outline: 'none'
          }}
          onMouseEnter={(e) => {
            if (currentPage !== item.id) {
              e.target.style.background = '#f9fafb';
              e.target.style.color = '#374151';
            }
          }}
          onMouseLeave={(e) => {
            if (currentPage !== item.id) {
              e.target.style.background = 'transparent';
              e.target.style.color = '#6b7280';
            }
          }}
        >
          <span style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            width: '20px',
            height: '20px',
            flexShrink: 0,
            opacity: currentPage === item.id ? 1 : 0.8
          }}>
            <IconComponent isActive={currentPage === item.id} />
          </span>
          {!isCollapsed && item.label}
        </button>
      </li>
    );
  };

  return (
    <nav style={{
      backgroundColor: '#ffffff',
      color: '#374151',
      width: isCollapsed ? '80px' : '260px',
      height: 'calc(100vh - 70px)',
      position: 'fixed',
      left: 0,
      top: '70px',
      display: 'flex',
      flexDirection: 'column',
      boxShadow: '1px 0 3px rgba(0,0,0,0.05)',
      borderRight: '1px solid #e5e7eb',
      transition: 'width 0.3s ease'
    }}>
      {/* Toggle Button */}
      <div style={{
        padding: '16px',
        borderBottom: '1px solid #e5e7eb',
        display: 'flex',
        justifyContent: isCollapsed ? 'center' : 'flex-end'
      }}>
        <button
          onClick={() => setIsCollapsed(!isCollapsed)}
          style={{
            background: 'transparent',
            border: '1px solid #e5e7eb',
            borderRadius: '6px',
            padding: '8px',
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            width: '32px',
            height: '32px',
            transition: 'all 0.15s ease',
            outline: 'none'
          }}
          onMouseEnter={(e) => {
            e.target.style.backgroundColor = '#f3f4f6';
            e.target.style.borderColor = '#1a1a1a';
          }}
          onMouseLeave={(e) => {
            e.target.style.backgroundColor = 'transparent';
            e.target.style.borderColor = '#e5e7eb';
          }}
        >
          <MenuIcon />
        </button>
      </div>

      {/* Top Navigation Section */}
      <div style={{ 
        flex: 1, 
        padding: isCollapsed ? '16px 8px' : '16px', 
        display: 'flex', 
        flexDirection: 'column',
        justifyContent: 'space-between'
      }}>
        <div>
          <ul style={{ 
            listStyle: 'none', 
            padding: 0, 
            margin: 0 
          }}>
            {topNavItems.map(renderNavButton)}
          </ul>
        </div>

        {/* Bottom Navigation Section */}
        <div style={{ 
          borderTop: '1px solid #e5e7eb', 
          paddingTop: '16px' 
        }}>
          <ul style={{ 
            listStyle: 'none', 
            padding: 0, 
            margin: 0 
          }}>
            {bottomNavItems.map(renderNavButton)}
          </ul>
        </div>
      </div>
    </nav>
  );
}

export default Navbar; 