import React, { useState } from 'react'

function Profile() {
  return (
    <div style={{ padding: '0', maxWidth: '1000px', margin: '0 auto' }}>
      <h1 style={{
        marginBottom: '8px',
        color: '#1a1a1a',
        fontSize: '28px',
        fontWeight: '600',
        letterSpacing: '-0.025em'
      }}>
        Profile
      </h1>
      <p style={{
        color: '#6b7280',
        marginBottom: '32px',
        fontSize: '16px',
        fontWeight: '400',
        lineHeight: '1.5'
      }}>
        Manage your account information and preferences
      </p>

      <div style={{
        backgroundColor: '#ffffff',
        border: '1px solid #e5e7eb',
        borderRadius: '12px',
        padding: '32px',
        boxShadow: '0 1px 3px rgba(0,0,0,0.05)'
      }}>
        <div style={{
          textAlign: 'center',
          padding: '48px 24px',
          color: '#6b7280'
        }}>
          <p style={{ fontSize: '18px', marginBottom: '16px' }}>👤</p>
          <p style={{ fontSize: '16px', fontWeight: '500' }}>Profile page is coming soon!</p>
          <p style={{ fontSize: '14px', margin: '8px 0 0 0' }}>Manage your personal information, preferences, and account settings.</p>
        </div>
      </div>
    </div>
  );
}

export default Profile;