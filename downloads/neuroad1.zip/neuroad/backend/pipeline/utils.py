import os, logging, shutil, subprocess, random, re
from pathlib import Path
from typing import Optional

from .config import LOG_LEVEL, SEED

def get_logger(name: str="pipeline"):
    logger = logging.getLogger(name)
    if not logger.handlers:
        handler = logging.StreamHandler()
        formatter = logging.Formatter("[%(asctime)s] %(levelname)s %(name)s: %(message)s")
        handler.setFormatter(formatter)
        logger.addHandler(handler)
    logger.setLevel(getattr(logging, LOG_LEVEL, logging.INFO))
    return logger

LOGGER = get_logger("pipeline")

_rng = random.Random(SEED)

def safe_slug(text: str, max_len: int = 64) -> str:
    text = text.strip().lower()
    text = re.sub(r"[^a-z0-9\-_.]+", "-", text)
    text = re.sub(r"-{2,}", "-", text).strip("-")
    return text[:max_len] or "item"

def which_ffmpeg() -> Optional[str]:
    path = shutil.which("ffmpeg")
    return path

def run_cmd(cmd: list, timeout: Optional[int]=None) -> int:
    try:
        res = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=timeout)
        return res.returncode
    except Exception:
        return 1
