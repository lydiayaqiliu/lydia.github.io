import torch
from PIL import Image
from typing import Union, List
from clip import load as load_clip
from pathlib import Path

MODEL_DIR = Path.home() / ".cache" / "clip"


import os

from .config import CLIP_MODEL_NAME

TEST_MODE = os.getenv("PIPELINE_TEST_MODE", "0") == "1"

def get_clip_embedding(
    image: Union[Image.Image, List[Image.Image]]
) -> torch.Tensor:
    """
    Compute CLIP embeddings for a PIL Image or list of PIL Images.
    Returns shape (1, dim) for single image, (N, dim) for list.
    """
    import os
    TEST_MODE = os.environ.get("TEST_MODE") == "1"
    device = "cuda" if torch.cuda.is_available() else "cpu"

    if TEST_MODE:
        import numpy as np
        dim = 4
        if isinstance(image, list):
            arr = np.tile(np.arange(0.1, 0.1 * (dim+1), 0.1)[:dim], (len(image), 1))
            return torch.tensor(arr, dtype=torch.float32)
        else:
            arr = np.arange(0.1, 0.1 * (dim+1), 0.1)[:dim]
            return torch.tensor(arr, dtype=torch.float32).unsqueeze(0)  # (1, dim)

    model, preprocess = load_clip("ViT-B/32", download_root=str(MODEL_DIR))
    if isinstance(image, list):
        imgs = [preprocess(img).unsqueeze(0) for img in image]
        batch = torch.cat(imgs, dim=0).to(device)
    else:
        batch = preprocess(image).unsqueeze(0).to(device)
    with torch.no_grad():
        emb = model.encode_image(batch)
    return emb
