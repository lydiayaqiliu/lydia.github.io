from pathlib import Path
from typing import List, Tuple
import io
import shutil
import pipeline

from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from PIL import Image

# ---- Config ----
UPLOAD_DIR = Path("uploads")
PROCESSED_SUBDIR = Path("pipeline_output")   # <— processed images live here
OUTPUT_DIR = Path("pipeline_output")
RAW_SUBDIR = "image"
source .venv/bin/activate 
#debug

import logging, sys
logging.basicConfig(
    level=logging.DEBUG,
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    stream=sys.stdout,
)



# Set your Vite origin here (or ["*"] while developing)
ALLOWED_ORIGINS = ["http://localhost:5173"]  # change to your real frontend origin(s)

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
app.mount("/uploads", StaticFiles(directory=str(UPLOAD_DIR)), name="uploads")
app.mount("/pipeline_output", StaticFiles(directory=str(OUTPUT_DIR)), name="pipeline_output")

# ---- Outbound HTTP tracing ----
import types

# requests
try:
    import requests
    import urllib3
    urllib3_logger = logging.getLogger("urllib3")
    urllib3_logger.setLevel(logging.DEBUG)
    logging.getLogger("requests").setLevel(logging.DEBUG)

    _orig_req = requests.sessions.Session.request
    def _wrapped_request(self, method, url, *args, **kwargs):
        logging.warning(f"[requests] {method} {url} verify={kwargs.get('verify', True)}")
        return _orig_req(self, method, url, *args, **kwargs)
    requests.sessions.Session.request = types.MethodType(_wrapped_request, requests.sessions.Session)
except Exception:
    pass

# httpx
try:
    import httpx
    logging.getLogger("httpx").setLevel(logging.DEBUG)
    _orig_httpx_req = httpx.Client.request
    def _wrapped_httpx(self, method, url, *args, **kwargs):
        logging.warning(f"[httpx] {method} {url} verify={kwargs.get('verify', True)}")
        return _orig_httpx_req(self, method, url, *args, **kwargs)
    httpx.Client.request = _wrapped_httpx
except Exception:
    pass

# urllib
try:
    import urllib.request as _urllib_request
    _orig_urlopen = _urllib_request.urlopen
    def _urlopen(url, *args, **kwargs):
        logging.warning(f"[urllib] urlopen {getattr(url, 'full_url', url)}")
        return _orig_urlopen(url, *args, **kwargs)
    _urllib_request.urlopen = _urlopen
except Exception:
    pass



def image_to_bytes(image_path: Path) -> bytes:
    with image_path.open("rb") as f:
        return f.read()

def bytes_to_png(image_bytes: bytes, output_path: Path) -> Path:
    """
    If bytes are already PNG, we could write directly; using PIL normalizes mode/format.
    """
    img = Image.open(io.BytesIO(image_bytes))
    if img.mode not in ("RGB", "RGBA"):
        img = img.convert("RGBA")
    output_path.parent.mkdir(parents=True, exist_ok=True)
    img.save(output_path, format="PNG")
    return output_path

def img_process_to_six(input_path: Path, *, prompt: str = "DTC promo; boost CTR; brand-safe") -> List[Path]:
    """
    Read input image, run the pipeline (Tuple[List[bytes], List[str]]),
    save up to 6 PNGs into OUTPUT_DIR, and return their Paths in order.
    """
    try:
        img_bytes: bytes = image_to_bytes(input_path)
        processed_imgs_bytes, _texts = pipeline.run.run_image_pipeline(img_bytes, 6, prompt)  # -> Tuple[List[bytes], List[str]]
    except Exception:
        logging.exception("Error in run_image_pipeline")
        raise

    if not processed_imgs_bytes:
        raise RuntimeError("Pipeline returned no processed images.")

    paths: List[Path] = []
    stem = input_path.stem
    for idx, png_bytes in enumerate(processed_imgs_bytes[:6]):  # ensure at most 6
        out_name = f"{stem}_var{idx+1}.png"
        out_path = OUTPUT_DIR / out_name
        # if your pipeline guarantees PNG bytes, you could: out_path.write_bytes(png_bytes)
        bytes_to_png(png_bytes, out_path)
        paths.append(out_path)

    return paths

# ---- Health ----
@app.get("/health")
def health():
    return {"status": "ok"}

# ---- Upload image -> generate six variations ----
@app.post("/api/uploadimage")
async def upload_image(
    file: UploadFile = File(...),
    folder: str = RAW_SUBDIR,
):
    try:
        # 1) Save original
        folder_path = UPLOAD_DIR / folder
        folder_path.mkdir(parents=True, exist_ok=True)
        save_path = folder_path / file.filename
        with save_path.open("wb") as buffer:
            shutil.copyfileobj(file.file, buffer)

        # 2) Process -> six PNGs in OUTPUT_DIR
        variant_paths: List[Path] = img_process_to_six(save_path)

        # 3) Build public URLs
        original_url = f"/uploads/{folder}/{file.filename}"
        processed_filenames = [p.name for p in variant_paths]
        processed_urls = [f"/pipeline_output/{p.name}" for p in variant_paths]

        return {
            "filename": file.filename,
            "url": original_url,
            "processed_filenames": processed_filenames,  # list[str]
            "processed_urls": processed_urls,            # list[str]
            "count": len(processed_urls),
            "content_type": "image/png",
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    
@app.post("/api/uploadvideo")
async def upload_file(
    file: UploadFile = File(...),
    folder: str = "video"
):
    folder_path = UPLOAD_DIR / folder
    folder_path.mkdir(parents=True, exist_ok=True)

    save_path = folder_path / file.filename
    with save_path.open("wb") as buffer:
        shutil.copyfileobj(file.file, buffer)

    return {"filename": file.filename, "url": f"/uploads/{folder}/{file.filename}"}

# Static file serving for uploads
from fastapi.staticfiles import StaticFiles
app.mount("/uploads", StaticFiles(directory=UPLOAD_DIR), name="uploads")
