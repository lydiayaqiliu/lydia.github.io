import os
from pathlib import Path
from pathlib import Path
OUTPUT_DIR = Path(__file__).resolve().parent.parent / "pipeline_output"
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)


# IMAGE_BACKEND: local_ops or sdxl
# VIDEO_BACKEND: local_ops or svd or luma
IMAGE_BACKEND = os.getenv("IMAGE_BACKEND", "sdxl").strip().lower()
VIDEO_BACKEND = os.getenv("VIDEO_BACKEND", "svd").strip().lower()

# prompt generation backend: "openai" or "local"
PROMPT_BACKEND = os.getenv("PROMPT_BACKEND", "local").strip().lower()

# OpenAI (optional)
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "").strip()
LLM_MODEL_NAME = os.getenv("LLM_MODEL_NAME", "gpt-4o-mini")

# luma API (optional)
LUMA_API_KEY = os.getenv("LUMA_API_KEY", "").strip()

# Diffusers local models (optional for generative)
SDXL_BASE = os.getenv("SDXL_BASE", "stabilityai/stable-diffusion-xl-base-1.0")
SDXL_REFINER = os.getenv("SDXL_REFINER", "stabilityai/stable-diffusion-xl-refiner-1.0")
SVD_MODEL = os.getenv("SVD_MODEL", "stabilityai/stable-video-diffusion-img2vid-xt-1-1")

# Embedding / VLM knobs
CLIP_MODEL_NAME = os.getenv("CLIP_MODEL_NAME", "ViT-B/32")

# Defaults
DEFAULT_VARIATIONS = int(os.getenv("DEFAULT_VARIATIONS", "6"))
DEFAULT_SPEC = os.getenv("DEFAULT_SPEC", "DTC promo; boost CTR; brand-safe")

# Processing
LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO").upper()
FPS = int(os.getenv("PIPELINE_FPS", "24"))
MAX_SIDE = int(os.getenv("MAX_SIDE", "1080"))

# Storage
TEMP_DIR = Path(os.getenv("TEMP_DIR", "/tmp/pipeline_temp"))
TEMP_DIR.mkdir(parents=True, exist_ok=True)

# File naming
IMG_EXT = os.getenv("IMG_EXT", ".png")
VID_EXT = os.getenv("VID_EXT", ".mp4")

# Video encoding
CV2_FOURCC = os.getenv("CV2_FOURCC", "mp4v")
CV2_BITRATE_KBPS = int(os.getenv("CV2_BITRATE_KBPS", "5000"))

# Subtitle settings
BURN_SUBTITLES = os.getenv("BURN_SUBTITLES", "false").lower() == "true"

# Determinism
SEED = int(os.getenv("SEED", "42"))

# Aspect ratio preference (used for generative prompts)
ASPECT = os.getenv("ASPECT", "4:5")

# Voiceover (optional ElevenLabs via ffmpeg mux)
VOICEOVER_ENABLED = os.getenv("VOICEOVER_ENABLED", "false").lower() == "true"
ELEVENLABS_API_KEY = os.getenv("ELEVENLABS_API_KEY", "").strip()
ELEVENLABS_VOICE_ID = os.getenv("ELEVENLABS_VOICE_ID", "21m00Tcm4TlvDq8ikWAM")
