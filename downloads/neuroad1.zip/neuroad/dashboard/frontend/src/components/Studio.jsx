import React, { useState } from 'react'
// [ADDED] import API helpers
import { API_BASE, apiUrl } from '../api';
export async function apiFetch(path, options = {}) {
  const res = await fetch(`${API_BASE}${path}`, options);
  if (!res.ok) {
    throw new Error(`API request failed: ${res.status}`);
  }
  return res.json();
}

const Studio = () => {
    const [videoLink, setVideoLink] = useState('');
    const [videoTitle, setVideoTitle] = useState('');
    const [videoDescription, setVideoDescription] = useState('');
    const [savedVideos, setSavedVideos] = useState([
        {
            id: 1,
            title: "Product Demo Video",
            link: "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
            description: "Main product demonstration for summer campaign",
            uploadedOn: "2024-12-18 10:30 AM"
        },
        {
            id: 2,
            title: "Brand Story",
            link: "https://vimeo.com/123456789",
            description: "Our company's origin story and mission",
            uploadedOn: "2024-12-17 2:15 PM"
        }
    ]);
    const [isUploading, setIsUploading] = useState(false);
    const [generated, setGenerated] = useState([]);


    // [ADDED - START] ------------ Upload logic (upload to backend for now) ----------

    // [CHANGED] use apiUrl so dev uses proxy and prod uses absolute base
    const uploadFileToBackend = async (file, kind /* 'videos' | 'images' */) => {
        const fd = new FormData();
        fd.append('file', file);
        fd.append('folder', kind);

        let endpoint;
        if (kind === 'videos') {
            endpoint = '/api/uploadvideo';
        } else if (kind === 'images') {
            endpoint = '/api/uploadimage';
        } else {
            throw new Error(`Unknown kind: ${kind}`);
        }

        const res = await fetch(endpoint, {
            method: 'POST',
            body: fd,
        });
        if (!res.ok) {
    const text = await res.text().catch(() => '');
        throw new Error(`API ${res.status} ${res.statusText}: ${text}`);
    }
    return res.json();
    };


    // [CHANGED] store an absolute link in prod, relative in dev
    const handlePickLocalVideo = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
        setIsUploading(true);
        const { url } = await uploadFileToBackend(file, 'videos');
        const publicUrl = `${API_BASE}${url}`; // empty in dev → relative; absolute in prod

        const newVideo = {
        id: Date.now(),
        title: videoTitle || file.name,
        link: publicUrl, // e.g. https://api.example.com/uploads/videos/...
        description: videoDescription,
        uploadedOn: new Date().toLocaleString(),
        };
        setSavedVideos(prev => [newVideo, ...prev]);
        setVideoTitle('');
        setVideoDescription('');
        alert('Video uploaded to backend.');
    } catch (err) {
        console.error(err);
        alert(err.message || 'Upload failed');
    } finally {
        e.target.value = '';
        setIsUploading(false);
    }
    };

    // [CHANGED] same pattern for images
    const handlePickLocalImage = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
        const res = await uploadFileToBackend(file, 'images');
        // currently you probably do something like:
        // setGenerated(prev => [...prev, res]);

        // This is where you replace with my new array-handling logic:
        const items = res.processed_urls.map((u, i) => ({
            id: Date.now() + i,
            url: `${API_BASE}${u}`, // prepend your backend base URL
            name: res.processed_filenames?.[i] || `${file.name}_var${i + 1}.png`,
            createdAt: new Date().toLocaleString(),
        }));

        setGenerated(prev => [...items, ...prev]);
    } catch (err) {
        console.error(err);
        alert(err.message || 'Upload failed');
    } finally {
        e.target.value = '';
        setIsUploading(false);
    }
    };

    // [ADDED - END] ------------ Upload logic (upload to backend for now) ----------


    const handleSubmit = (e) => {
        e.preventDefault();

        if (!videoLink.trim() || !videoTitle.trim()) {
            alert('Please provide both video title and link');
            return;
        }

        setIsUploading(true);

        // Simulate upload delay
        setTimeout(() => {
            const newVideo = {
                id: Date.now(),
                title: videoTitle,
                link: videoLink,
                description: videoDescription,
                uploadedOn: new Date().toLocaleString()
            };

            setSavedVideos([newVideo, ...savedVideos]);
            setVideoLink('');
            setVideoTitle('');
            setVideoDescription('');
            setIsUploading(false);
        }, 1000);
    };

    const handleDelete = (videoId) => {
        if (window.confirm('Are you sure you want to delete this video?')) {
            setSavedVideos(savedVideos.filter(video => video.id !== videoId));
        }
    };

    const getVideoThumbnail = (link) => {
        // Extract video ID and return thumbnail for preview
        if (link.includes('youtube.com') || link.includes('youtu.be')) {
            const videoId = link.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/)([^&\n?#]+)/);
            return videoId ? `https://img.youtube.com/vi/${videoId[1]}/mqdefault.jpg` : null;
        }
        return null;
    };

    return (
        <div style={{ padding: '0', maxWidth: '1000px', margin: '0 auto' }}>
            <h1 style={{
                marginBottom: '8px',
                color: '#1a1a1a',
                fontSize: '28px',
                fontWeight: '600',
                letterSpacing: '-0.025em'
            }}>
                Studio
            </h1>
            <p style={{
                color: '#6b7280',
                marginBottom: '32px',
                fontSize: '16px',
                fontWeight: '400',
                lineHeight: '1.5'
            }}>
                Upload and manage your video content
            </p>

            {/* Upload Form */}
            <div style={{
                backgroundColor: '#ffffff',
                border: '1px solid #e5e7eb',
                borderRadius: '12px',
                padding: '28px',
                marginBottom: '32px',
                boxShadow: '0 1px 3px rgba(0,0,0,0.05)'
            }}>
                <h3 style={{
                    margin: '0 0 24px 0',
                    color: '#1a1a1a',
                    fontSize: '18px',
                    fontWeight: '600',
                    letterSpacing: '-0.025em'
                }}>
                    Upload New Video
                </h3>

                <form onSubmit={handleSubmit}>
                    <div style={{ marginBottom: '24px' }}>
                        <label style={{
                            display: 'block',
                            marginBottom: '8px',
                            fontSize: '14px',
                            fontWeight: '500',
                            color: '#1a1a1a',
                            letterSpacing: '-0.01em'
                        }}>
                            Video Title *
                        </label>
                        <input
                            type="text"
                            value={videoTitle}
                            onChange={(e) => setVideoTitle(e.target.value)}
                            placeholder="Enter video title"
                            style={{
                                width: 'calc(100% - 24px)',
                                padding: '12px',
                                border: '1px solid #d1d5db',
                                borderRadius: '8px',
                                fontSize: '14px',
                                outline: 'none',
                                transition: 'border-color 0.15s ease',
                                fontWeight: '400',
                                letterSpacing: '-0.01em'
                            }}
                            onFocus={(e) => e.target.style.borderColor = '#1a1a1a'}
                            onBlur={(e) => e.target.style.borderColor = '#d1d5db'}
                        />
                    </div>

                    <div style={{ marginBottom: '24px' }}>
                        <label style={{
                            display: 'block',
                            marginBottom: '8px',
                            fontSize: '14px',
                            fontWeight: '500',
                            color: '#1a1a1a',
                            letterSpacing: '-0.01em'
                        }}>
                            Video Link *
                        </label>
                        <input
                            type="url"
                            value={videoLink}
                            onChange={(e) => setVideoLink(e.target.value)}
                            placeholder="https://www.youtube.com/watch?v=... or https://vimeo.com/..."
                            style={{
                                width: 'calc(100% - 24px)',
                                padding: '12px',
                                border: '1px solid #d1d5db',
                                borderRadius: '8px',
                                fontSize: '14px',
                                outline: 'none',
                                transition: 'border-color 0.15s ease',
                                fontWeight: '400',
                                letterSpacing: '-0.01em'
                            }}
                            onFocus={(e) => e.target.style.borderColor = '#1a1a1a'}
                            onBlur={(e) => e.target.style.borderColor = '#d1d5db'}
                        />
                    </div>

                    <div style={{ marginBottom: '24px' }}>
                        <label style={{
                            display: 'block',
                            marginBottom: '8px',
                            fontSize: '14px',
                            fontWeight: '500',
                            color: '#1a1a1a',
                            letterSpacing: '-0.01em'
                        }}>
                            Description
                        </label>
                        <textarea
                            value={videoDescription}
                            onChange={(e) => setVideoDescription(e.target.value)}
                            placeholder="Optional description for this video"
                            rows="3"
                            style={{
                                width: 'calc(100% - 24px)',
                                padding: '12px',
                                border: '1px solid #d1d5db',
                                borderRadius: '8px',
                                fontSize: '14px',
                                outline: 'none',
                                transition: 'border-color 0.15s ease',
                                resize: 'vertical',
                                fontFamily: 'inherit',
                                fontWeight: '400',
                                letterSpacing: '-0.01em',
                                lineHeight: '1.5'
                            }}
                            onFocus={(e) => e.target.style.borderColor = '#1a1a1a'}
                            onBlur={(e) => e.target.style.borderColor = '#d1d5db'}
                        />
                    </div>

                    <button
                        type="submit"
                        disabled={isUploading}
                        style={{
                            backgroundColor: isUploading ? '#9ca3af' : '#1a1a1a',
                            color: 'white',
                            border: 'none',
                            borderRadius: '8px',
                            padding: '12px 24px',
                            fontSize: '14px',
                            fontWeight: '500',
                            cursor: isUploading ? 'not-allowed' : 'pointer',
                            transition: 'all 0.15s ease',
                            letterSpacing: '-0.01em'
                        }}
                        onMouseEnter={(e) => {
                            if (!isUploading) {
                                e.target.style.backgroundColor = '#2a2a2a';
                                e.target.style.transform = 'translateY(-1px)';
                            }
                        }}
                        onMouseLeave={(e) => {
                            if (!isUploading) {
                                e.target.style.backgroundColor = '#1a1a1a';
                                e.target.style.transform = 'translateY(0)';
                            }
                        }}
                    >
                        {isUploading ? 'Saving...' : 'Save Video'}
                    </button>

                    {/* [ADDED - START] Buttons + hidden inputs for local uploads */}
                    <div style={{ marginTop: '16px', display: 'flex', gap: '12px', alignItems: 'center' }}>
                        <button
                            type="button"
                            disabled={isUploading}
                            onClick={() => document.getElementById('localVideoInput')?.click()}
                            style={{
                                backgroundColor: isUploading ? '#9ca3af' : '#111827',
                                color: 'white',
                                border: 'none',
                                borderRadius: '8px',
                                padding: '10px 16px',
                                fontSize: '14px',
                                cursor: isUploading ? 'not-allowed' : 'pointer'
                            }}
                        >
                            Upload Local Video
                        </button>

                        <button
                            type="button"
                            disabled={isUploading}
                            onClick={() => document.getElementById('localImageInput')?.click()}
                            style={{
                                backgroundColor: isUploading ? '#9ca3af' : '#374151',
                                color: 'white',
                                border: 'none',
                                borderRadius: '8px',
                                padding: '10px 16px',
                                fontSize: '14px',
                                cursor: isUploading ? 'not-allowed' : 'pointer'
                            }}
                        >
                            Upload Local Image
                        </button>

                        {/* hidden file inputs */}
                        <input
                            id="localVideoInput"
                            type="file"
                            accept="video/*"
                            onChange={handlePickLocalVideo}
                            style={{ display: 'none' }}
                        />
                        <input
                            id="localImageInput"
                            type="file"
                            accept="image/*"
                            onChange={handlePickLocalImage}
                            style={{ display: 'none' }}
                        />
                    </div>
                    {/* [ADDED - END] Buttons + hidden inputs for local uploads */}
                </form>
            </div>

            {/* Generated Variations */}
            <div style={{
            backgroundColor: '#ffffff',
            border: '1px solid #e5e7eb',
            borderRadius: '12px',
            padding: '28px',
            marginTop: '32px',
            boxShadow: '0 1px 3px rgba(0,0,0,0.05)'
            }}>
            <h3 style={{
                margin: '0 0 24px 0',
                color: '#1a1a1a',
                fontSize: '18px',
                fontWeight: '600',
                letterSpacing: '-0.025em'
            }}>
                Generated Variations ({generated.length})
            </h3>

            {generated.length === 0 ? (
                <p style={{ color: '#6b7280', fontStyle: 'italic' }}>No generated images yet.</p>
            ) : (
                <div style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(auto-fill, minmax(180px, 1fr))',
                gap: '16px'
                }}>
                {generated.map(img => (
                    <div key={img.id} style={{
                    border: '1px solid #e5e7eb',
                    borderRadius: '8px',
                    padding: '12px',
                    backgroundColor: '#fafafa'
                    }}>
                    <div style={{
                        width: '100%',
                        aspectRatio: '1/1',
                        backgroundColor: '#e5e7eb',
                        borderRadius: '6px',
                        overflow: 'hidden',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center'
                    }}>
                        <img
                        src={img.url}
                        alt={img.name}
                        style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                        loading="lazy"
                        />
                    </div>
                    <div style={{ marginTop: '8px', fontSize: '12px', color: '#6b7280' }}>
                        <div title={img.name} style={{
                        whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis'
                        }}>{img.name}</div>
                        <div>{img.createdAt}</div>
                        <a href={img.url} target="_blank" rel="noopener noreferrer" style={{
                        display: 'inline-block', marginTop: '6px', fontWeight: 500, color: '#1a1a1a', textDecoration: 'none'
                        }}>
                        Open
                        </a>
                    </div>
                    </div>
                ))}
                </div>
            )}
            </div>


            {/* Saved Videos */}
            <div style={{
                backgroundColor: '#ffffff',
                border: '1px solid #e5e7eb',
                borderRadius: '12px',
                padding: '28px',
                boxShadow: '0 1px 3px rgba(0,0,0,0.05)'
            }}>
                <h3 style={{
                    margin: '0 0 24px 0',
                    color: '#1a1a1a',
                    fontSize: '18px',
                    fontWeight: '600',
                    letterSpacing: '-0.025em'
                }}>
                    Saved Videos ({savedVideos.length})
                </h3>

                {savedVideos.length === 0 ? (
                    <p style={{ color: '#6b7280', fontStyle: 'italic' }}>No videos uploaded yet.</p>
                ) : (
                    <div style={{ display: 'grid', gap: '16px' }}>
                        {savedVideos.map(video => {
                            const thumbnail = getVideoThumbnail(video.link);
                            return (
                                <div key={video.id} style={{
                                    display: 'flex',
                                    gap: '16px',
                                    padding: '16px',
                                    border: '1px solid #e5e7eb',
                                    borderRadius: '8px',
                                    backgroundColor: '#fafafa'
                                }}>
                                    <div style={{
                                        width: '120px',
                                        height: '68px',
                                        backgroundColor: '#e5e7eb',
                                        borderRadius: '6px',
                                        display: 'flex',
                                        alignItems: 'center',
                                        justifyContent: 'center',
                                        overflow: 'hidden',
                                        flexShrink: 0
                                    }}>
                                        {thumbnail ? (
                                            <img 
                                                src={thumbnail} 
                                                alt="Video thumbnail"
                                                style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                                            />
                                        ) : (
                                            <span style={{ fontSize: '12px', color: '#6b7280' }}>📹</span>
                                        )}
                                    </div>
                                    <div style={{ flex: 1 }}>
                                        <h4 style={{
                                            margin: '0 0 8px 0',
                                            color: '#1a1a1a',
                                            fontSize: '16px',
                                            fontWeight: '600'
                                        }}>
                                            {video.title}
                                        </h4>
                                        <p style={{
                                            margin: '0 0 8px 0',
                                            color: '#6b7280',
                                            fontSize: '14px',
                                            lineHeight: '1.4'
                                        }}>
                                            {video.description}
                                        </p>
                                        <div style={{
                                            display: 'flex',
                                            alignItems: 'center',
                                            gap: '16px',
                                            fontSize: '12px',
                                            color: '#9ca3af'
                                        }}>
                                            <span>Uploaded: {video.uploadedOn}</span>
                                            <a href={video.link} target="_blank" rel="noopener noreferrer" style={{
                                                color: '#1a1a1a',
                                                textDecoration: 'none',
                                                fontWeight: '500'
                                            }}>
                                                View
                                            </a>
                                            <button
                                                onClick={() => handleDelete(video.id)}
                                                style={{
                                                    background: 'none',
                                                    border: 'none',
                                                    color: '#ef4444',
                                                    cursor: 'pointer',
                                                    fontWeight: '500',
                                                    fontSize: '12px'
                                                }}
                                            >
                                                Delete
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                )}
            </div>
        </div>
        
    );
    
};

export default Studio; 