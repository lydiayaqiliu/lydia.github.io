import json
from typing import Any, List, Optional, Dict
from .config import (
    OPENAI_API_KEY, LLM_MODEL_NAME, DEFAULT_SPEC, DEFAULT_VARIATIONS, PROMPT_BACKEND, ASPECT
)

_SYS = (
    "You are a senior ad creative + director. Produce concrete VARIATION PLANS that might help the advertisement perform better based on accepted heuristics and business and advertising knowledge as JSON.\n"
    "Each item object fields:\n"
    "  title, style_tags[list], scene, camera, copy, prompt, negative, guidance(3..12), strength(0.2..0.85), motion, aspect.\n"
    "Return ONLY a JSON list."
)

def _openai_generate(spec: str, n: int, visual_hint: Optional[str]) -> List[Dict]:
    try:
        from openai import OpenAI
    except Exception:
        raise RuntimeError("OpenAI SDK not available.")
    if not OPENAI_API_KEY:
        raise RuntimeError("OpenAI API key missing.")
    client = OpenAI(api_key=OPENAI_API_KEY)
    user = {
        "spec": spec,
        "visual_hint": visual_hint or "",
        "n": n,
        "aspect": ASPECT,
        "notes": "Prefer brand-safe, conversion-oriented motifs; executable by SDXL/SVD/Luma."
    }
    resp = client.chat.completions.create(
        model=LLM_MODEL_NAME,
        messages=[{"role":"system","content":_SYS},
                  {"role":"user","content":json.dumps(user)}],
        response_format={"type":"json_object"},
        temperature=0.9, max_tokens=1200,
    )
    txt = resp.choices[0].message.content or "{}"
    try:
        data = json.loads(txt)
        items = data.get("items") if isinstance(data, dict) else data
        if not isinstance(items, list): raise ValueError
        return items[:n]
    except Exception:
        return []

def _local_templates(spec: str, n: int, aspect: str) -> List[Dict]:
    base: List[Dict] = [
        {
            "title": "Lifestyle — Sunlit Kitchen",
            "style_tags": ["natural light","clean","warm"],
            "scene": "Bright kitchen countertop with soft window light; add fruit bowl.",
            "camera": "35mm eye-level, slight push-in",
            "copy": "Make mornings easier — Shop now",
            "prompt": "lifestyle product on countertop, soft sunlight, clean styling, cozy, premium, realistic details",
            "negative": "lowres, artifacts, extra limbs, text warping, watermark",
            "guidance": 6.5, "strength": 0.45, "motion": "slow push-in", "aspect": aspect
        },
        {
            "title": "Urban — Neon Contrast",
            "style_tags": ["punchy","neon","high-contrast"],
            "scene": "Night city alley with neon signs; wet reflective ground.",
            "camera": "24mm low angle, slight dutch tilt",
            "copy": "Own the night →",
            "prompt": "cinematic neon, wet asphalt reflections, vibrant color, dramatic contrast, premium",
            "negative": "blurry, overexposed, banding, watermark",
            "guidance": 7.5, "strength": 0.6, "motion": "parallax", "aspect": aspect
        },
        {
            "title": "Studio — Minimal",
            "style_tags": ["minimal","e-commerce","clean"],
            "scene": "Seamless off-white backdrop with soft shadow.",
            "camera": "50mm product-centered, locked-off",
            "copy": "Meet your new daily essential",
            "prompt": "studio seamless backdrop, soft shadows, crisp product, premium e-commerce aesthetic",
            "negative": "text, watermark, jpeg artifacts",
            "guidance": 5.5, "strength": 0.35, "motion": "", "aspect": aspect
        },
        {
            "title": "Nature — Forest Morning",
            "style_tags": ["organic","mist","greenery"],
            "scene": "Soft misty forest clearing; rays of light.",
            "camera": "35mm eye-level, slow dolly left",
            "copy": "Naturally better",
            "prompt": "misty forest clearing, volumetric light, dewy leaves, serene, premium ad look",
            "negative": "cartoonish, deformed, watermark",
            "guidance": 6.8, "strength": 0.55, "motion": "slow pan", "aspect": aspect
        },
        {
            "title": "Retro — Film Grain",
            "style_tags": ["retro","grain","halation"],
            "scene": "1970s living room palette; warm halation glow.",
            "camera": "35mm mid-shot, static",
            "copy": "Classic comfort — Today",
            "prompt": "retro film look, genuine grain, warm halation, period color palette, premium",
            "negative": "noise artifacts, flicker, watermark",
            "guidance": 7.0, "strength": 0.5, "motion": "gentle zoom", "aspect": aspect
        },
        {
            "title": "Energetic — Kinetic Text",
            "style_tags": ["bold","kinetic","social-first"],
            "scene": "Abstract colorful shapes background.",
            "camera": "dynamic cuts, 3-beat sequence",
            "copy": "Tap to save 20%",
            "prompt": "colorful abstract gradients, bold shapes, social first, dynamic",
            "negative": "illegible text, compression artifacts, watermark",
            "guidance": 8.0, "strength": 0.65, "motion": "quick cuts", "aspect": aspect
        }
    ]
    out = []
    i = 0
    while len(out) < n:
        out.append(base[i % len(base)])
        i += 1
    return out[:n]

def _summarize_visuals(embedding: Any) -> Optional[str]:
    if embedding is None: return None
    if hasattr(embedding, "shape"):
        return f"Visual embedding shape {tuple(getattr(embedding, 'shape', []))}"
    return "Visual context available"

def generate_prompts(embedding: Any, spec: str = DEFAULT_SPEC, n: int = DEFAULT_VARIATIONS) -> List[dict]:
    visual_hint = _summarize_visuals(embedding)
    if PROMPT_BACKEND == "openai" and OPENAI_API_KEY:
        try:
            ideas = _openai_generate(spec, n, visual_hint)
            if ideas:
                return ideas[:n]
        except Exception:
            pass
    return _local_templates(spec, n, ASPECT)
