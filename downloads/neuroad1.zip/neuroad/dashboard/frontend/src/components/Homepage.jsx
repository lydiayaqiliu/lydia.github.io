const Homepage = ({ setCurrentPage }) => {
    // Sample data - in real app this would come from API
    const recentAds = [
        { id: 1, name: "Summer Campaign", status: "Running", lastModified: "2 hours ago" },
        { id: 2, name: "Product Launch", status: "Paused", lastModified: "1 day ago" },
        { id: 3, name: "Holiday Special", status: "Scheduled", lastModified: "3 days ago" },
        { id: 4, name: "Brand Awareness", status: "Running", lastModified: "5 days ago" },
        { id: 5, name: "Retargeting Campaign", status: "Draft", lastModified: "1 week ago" }
    ];

    const recentReports = [
        { id: 1, name: "Weekly Performance", type: "Performance", generatedOn: "Today, 9:30 AM" },
        { id: 2, name: "Audience Insights", type: "Analytics", generatedOn: "Yesterday, 2:15 PM" },
        { id: 3, name: "Campaign ROI", type: "Financial", generatedOn: "Dec 15, 2024" },
        { id: 4, name: "User Engagement", type: "Audience", generatedOn: "Dec 14, 2024" },
        { id: 5, name: "Monthly Summary", type: "Campaign", generatedOn: "Dec 13, 2024" }
    ];

    const getStatusColor = (status) => {
        switch (status) {
            case 'Running': return '#10b981';
            case 'Paused': return '#f59e0b';
            case 'Scheduled': return '#3b82f6';
            case 'Draft': return '#6b7280';
            default: return '#6b7280';
        }
    };

    const getReportTypeColor = (type) => {
        switch (type) {
            case 'Performance': return '#8b5cf6';
            case 'Analytics': return '#06b6d4';
            case 'Financial': return '#10b981';
            case 'Audience': return '#f59e0b';
            case 'Campaign': return '#ef4444';
            default: return '#6b7280';
        }
    };

    const handleCreateNewAd = () => {
        console.log("Creating new ad...");
        setCurrentPage('studio');
    };

    return (
        <div style={{ padding: '0', maxWidth: '1200px', margin: '0 auto' }}>
            {/* Create New Ad Section */}
            <div
                style={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    backgroundColor: '#ffffff',
                    border: '2px dashed #d1d5db',
                    borderRadius: '12px',
                    padding: '24px 28px',
                    marginBottom: '32px',
                    cursor: 'pointer',
                    transition: 'all 0.2s ease',
                    boxShadow: '0 1px 3px rgba(0,0,0,0.05)'
                }}
                onClick={handleCreateNewAd}
                onMouseEnter={(e) => {
                    e.target.style.backgroundColor = '#f9fafb';
                    e.target.style.borderColor = '#1a1a1a';
                    e.target.style.boxShadow = '0 4px 6px rgba(0,0,0,0.05)';
                }}
                onMouseLeave={(e) => {
                    e.target.style.backgroundColor = '#ffffff';
                    e.target.style.borderColor = '#d1d5db';
                    e.target.style.boxShadow = '0 1px 3px rgba(0,0,0,0.05)';
                }}
            >
                <div>
                    <h3 style={{
                        margin: '0 0 6px 0',
                        color: '#1a1a1a',
                        fontSize: '18px',
                        fontWeight: '600',
                        letterSpacing: '-0.025em'
                    }}>
                        Create a new ad
                    </h3>
                    <p style={{
                        margin: '0',
                        color: '#6b7280',
                        fontSize: '14px',
                        fontWeight: '400'
                    }}>
                        Start building your next advertising campaign
                    </p>
                </div>
                <button
                    style={{
                        backgroundColor: '#1a1a1a',
                        color: 'white',
                        border: 'none',
                        borderRadius: '10px',
                        width: '48px',
                        height: '48px',
                        fontSize: '20px',
                        cursor: 'pointer',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        transition: 'all 0.2s ease',
                        boxShadow: '0 4px 6px rgba(26,26,26,0.15)',
                        fontWeight: '300'
                    }}
                    onMouseEnter={(e) => {
                        e.target.style.backgroundColor = '#2a2a2a';
                        e.target.style.transform = 'translateY(-1px)';
                        e.target.style.boxShadow = '0 6px 8px rgba(26,26,26,0.2)';
                    }}
                    onMouseLeave={(e) => {
                        e.target.style.backgroundColor = '#1a1a1a';
                        e.target.style.transform = 'translateY(0)';
                        e.target.style.boxShadow = '0 4px 6px rgba(26,26,26,0.15)';
                    }}
                >
                    +
                </button>
            </div>

            {/* Recent Items Grid */}
            <div style={{
                display: 'grid',
                gridTemplateColumns: '1fr 1fr',
                gap: '32px'
            }}>
                {/* Recent Advertisements */}
                <div style={{
                    backgroundColor: '#ffffff',
                    border: '1px solid #e5e7eb',
                    borderRadius: '12px',
                    padding: '24px',
                    boxShadow: '0 1px 3px rgba(0,0,0,0.05)'
                }}>
                    <div style={{
                        display: 'flex',
                        justifyContent: 'space-between',
                        alignItems: 'center',
                        marginBottom: '20px'
                    }}>
                        <h3 style={{
                            margin: '0',
                            color: '#1a1a1a',
                            fontSize: '18px',
                            fontWeight: '600',
                            letterSpacing: '-0.025em'
                        }}>
                            Recent Advertisements
                        </h3>
                        <button
                            onClick={() => setCurrentPage('ads')}
                            style={{
                                backgroundColor: 'transparent',
                                border: '1px solid #d1d5db',
                                color: '#374151',
                                borderRadius: '6px',
                                padding: '6px 12px',
                                fontSize: '12px',
                                fontWeight: '500',
                                cursor: 'pointer',
                                transition: 'all 0.15s ease',
                                letterSpacing: '-0.01em'
                            }}
                            onMouseEnter={(e) => {
                                e.target.style.backgroundColor = '#f3f4f6';
                                e.target.style.borderColor = '#1a1a1a';
                            }}
                            onMouseLeave={(e) => {
                                e.target.style.backgroundColor = 'transparent';
                                e.target.style.borderColor = '#d1d5db';
                            }}
                        >
                            View All Ads
                        </button>
                    </div>

                    <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                        {recentAds.map(ad => (
                            <div key={ad.id} style={{
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'space-between',
                                padding: '12px 0',
                                borderBottom: '1px solid #f3f4f6'
                            }}>
                                <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                                    <div style={{
                                        width: '8px',
                                        height: '8px',
                                        borderRadius: '50%',
                                        backgroundColor: getStatusColor(ad.status)
                                    }}></div>
                                    <div>
                                        <p style={{
                                            margin: '0 0 2px 0',
                                            fontWeight: '500',
                                            fontSize: '14px',
                                            color: '#1a1a1a'
                                        }}>
                                            {ad.name}
                                        </p>
                                        <p style={{
                                            margin: '0',
                                            fontSize: '12px',
                                            color: '#6b7280'
                                        }}>
                                            {ad.status}
                                        </p>
                                    </div>
                                </div>
                                <span style={{
                                    fontSize: '11px',
                                    color: '#9ca3af',
                                    fontWeight: '400'
                                }}>
                                    {ad.lastModified}
                                </span>
                            </div>
                        ))}
                    </div>
                </div>

                {/* Recent Reports */}
                <div style={{
                    backgroundColor: '#ffffff',
                    border: '1px solid #e5e7eb',
                    borderRadius: '12px',
                    padding: '24px',
                    boxShadow: '0 1px 3px rgba(0,0,0,0.05)'
                }}>
                    <div style={{
                        display: 'flex',
                        justifyContent: 'space-between',
                        alignItems: 'center',
                        marginBottom: '20px'
                    }}>
                        <h3 style={{
                            margin: '0',
                            color: '#1a1a1a',
                            fontSize: '18px',
                            fontWeight: '600',
                            letterSpacing: '-0.025em'
                        }}>
                            Recent Reports
                        </h3>
                        <button
                            onClick={() => setCurrentPage('reports')}
                            style={{
                                backgroundColor: 'transparent',
                                border: '1px solid #d1d5db',
                                color: '#374151',
                                borderRadius: '6px',
                                padding: '6px 12px',
                                fontSize: '12px',
                                fontWeight: '500',
                                cursor: 'pointer',
                                transition: 'all 0.15s ease',
                                letterSpacing: '-0.01em'
                            }}
                            onMouseEnter={(e) => {
                                e.target.style.backgroundColor = '#f3f4f6';
                                e.target.style.borderColor = '#1a1a1a';
                            }}
                            onMouseLeave={(e) => {
                                e.target.style.backgroundColor = 'transparent';
                                e.target.style.borderColor = '#d1d5db';
                            }}
                        >
                            View All Reports
                        </button>
                    </div>

                    <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                        {recentReports.map(report => (
                            <div key={report.id} style={{
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'space-between',
                                padding: '12px 0',
                                borderBottom: '1px solid #f3f4f6'
                            }}>
                                <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                                    <div style={{
                                        width: '8px',
                                        height: '8px',
                                        borderRadius: '50%',
                                        backgroundColor: getReportTypeColor(report.type)
                                    }}></div>
                                    <div>
                                        <p style={{
                                            margin: '0 0 2px 0',
                                            fontWeight: '500',
                                            fontSize: '14px',
                                            color: '#1a1a1a'
                                        }}>
                                            {report.name}
                                        </p>
                                        <p style={{
                                            margin: '0',
                                            fontSize: '12px',
                                            color: '#6b7280'
                                        }}>
                                            {report.type}
                                        </p>
                                    </div>
                                </div>
                                <span style={{
                                    fontSize: '11px',
                                    color: '#9ca3af',
                                    fontWeight: '400'
                                }}>
                                    {report.generatedOn}
                                </span>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Homepage; 