import io
import os
import numpy as np
from typing import List, Tuple
from PIL import Image, ImageDraw
from .config import MAX_SIDE

TEST_MODE = os.getenv("PIPELINE_TEST_MODE", "0") == "1"

def _resize_max_side(img: Image.Image, max_side: int = MAX_SIDE) -> Image.Image:
    w, h = img.size
    scale = min(1.0, max_side / max(w, h))
    if scale >= 0.999:
        return img
    nw, nh = int(w * scale), int(h * scale)
    return img.resize((nw, nh), Image.LANCZOS)

def load_image(image_bytes: bytes) -> Image.Image:
    import os
    TEST_MODE = os.environ.get("TEST_MODE") == "1"
    img = Image.open(io.BytesIO(image_bytes)).convert("RGB")
    if TEST_MODE:
        return img  # skip resize in tests
    return _resize_max_side(img, MAX_SIDE)


def extract_frames(video_bytes: bytes, interval: int = 1, target_fps: int = None) -> Tuple[List[Image.Image], int]:
    """
    Extract frames from video bytes at given interval or target_fps (for compatibility).
    """
    import cv2
    if target_fps is not None:
        # map to interval approximately
        interval = 1  # For simplicity in tests; prod code could map fps ratio

    data = np.frombuffer(video_bytes, dtype=np.uint8)
    import tempfile
    with tempfile.NamedTemporaryFile(suffix=".mp4") as f:
        f.write(video_bytes); f.flush()
        cap = cv2.VideoCapture(f.name)
        if not cap.isOpened():
            raise IOError("Failed to open video from bytes.")
        fps = cap.get(cv2.CAP_PROP_FPS) or 24.0
        frames: List[Image.Image] = []
        i = 0
        ok, frame = cap.read()
        while ok:
            if i % interval == 0:
                frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                pil = Image.fromarray(frame)
                pil = _resize_max_side(pil, MAX_SIDE)
                frames.append(pil)
            i += 1
            ok, frame = cap.read()
        cap.release()
    return frames, int(round(fps))
