import os
import random
import numpy as np
from typing import Any, List, Dict
from PIL import Image, ImageDraw
from pathlib import Path

from .config import (
    FPS, SEED, BURN_SUBTITLES,
    IMAGE_BACKEND, VIDEO_BACKEND,
    OUTPUT_DIR
)

TEST_MODE = os.getenv("PIPELINE_TEST_MODE", "0") == "1"
random.seed(SEED)

def _cv2_from_pil(img: Image.Image) -> np.ndarray:
    import cv2
    return cv2.cvtColor(np.array(img), cv2.COLOR_RGB2BGR)

def _pil_from_cv2(arr: np.ndarray) -> Image.Image:
    import cv2
    return Image.fromarray(cv2.cvtColor(arr, cv2.COLOR_BGR2RGB))

def _ensure_font(size: int = 48):
    from PIL import ImageFont
    for name in ["Inter.ttf", "DejaVuSans.ttf", "Arial.ttf"]:
        try:
            return ImageFont.truetype(name, size)
        except Exception:
            continue
    return ImageFont.load_default()

def _apply_grade(img: Image.Image, mode: str) -> Image.Image:
    """
    Apply a visual grade to an image.
    In TEST_MODE this just overlays text instead of heavy OpenCV ops.
    """
    if TEST_MODE:
        im = img.copy()
        draw = ImageDraw.Draw(im)
        draw.text((10, 10), f"[GRADE: {mode}]", fill=(255, 0, 0))
        return im

    import cv2
    arr = _cv2_from_pil(img)
    if mode == "cinematic":
        lab = cv2.cvtColor(arr, cv2.COLOR_BGR2LAB)
        l, a, b = cv2.split(lab)
        clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8,8))
        l2 = clahe.apply(l)
        arr2 = cv2.cvtColor(cv2.merge([l2,a,b]), cv2.COLOR_LAB2BGR)
        arr2 = cv2.convertScaleAbs(arr2, alpha=1.1, beta=10)
        return _pil_from_cv2(arr2)
    if mode == "punchy":
        arr2 = cv2.convertScaleAbs(arr, alpha=1.2, beta=5)
        return _pil_from_cv2(arr2)
    if mode == "minimal":
        gray = cv2.cvtColor(arr, cv2.COLOR_BGR2GRAY)
        gray3 = cv2.cvtColor(gray, cv2.COLOR_GRAY2BGR)
        arr2 = cv2.addWeighted(arr, 0.5, gray3, 0.5, 0)
        return _pil_from_cv2(arr2)
    if mode == "retro":
        noise = np.random.normal(0, 8, arr.shape).astype(np.int16)
        arr2 = np.clip(arr.astype(np.int16) + noise, 0, 255).astype(np.uint8)
        return _pil_from_cv2(arr2)
    if mode == "sketch":
        gray = cv2.cvtColor(arr, cv2.COLOR_BGR2GRAY)
        inv = 255 - gray
        blur = cv2.GaussianBlur(inv, (21,21), 0)
        sketch = cv2.divide(gray, 255 - blur, scale=256)
        sketch3 = cv2.cvtColor(sketch, cv2.COLOR_GRAY2RGB)
        return Image.fromarray(sketch3)
    return img

def _place_text(img: Image.Image, text: str, position: str = "bottom", padding: int = 24,
                bgcolor=(0,0,0,140), fgcolor=(255,255,255,255), font_size: int = 48) -> Image.Image:
    """
    Overlay text on an image.
    In TEST_MODE this is kept minimal.
    """
    im = img.copy()
    draw = ImageDraw.Draw(im, "RGBA")
    font = _ensure_font(font_size)
    w, h = im.size
    tw, th = draw.textbbox((0,0), text, font=font)[2:]
    box_h = th + padding * 2
    if position == "top":
        y0 = 0
    elif position == "bottom":
        y0 = h - box_h
    else:
        y0 = (h - box_h) // 2
    draw.rectangle([0, y0, w, y0 + box_h], fill=bgcolor)
    draw.text((padding, y0 + padding), text, font=font, fill=fgcolor)
    return im

def generate_image_variations(image: Image.Image, ideas: List[Dict] = None, **kwargs) -> List[Image.Image]:
    if TEST_MODE:
        results = []
        prompts = ideas or kwargs.get("prompts") or []
        for idx, _ in enumerate(prompts):
            img = image.copy()
            draw = ImageDraw.Draw(img)
            draw.text((10, 10), f"VAR {idx+1}", fill=(255, 0, 0))
            results.append(img)
        return results
    from .backends import get_image_backend
    backend = get_image_backend(IMAGE_BACKEND)
    return backend.image_variations(image, ideas or kwargs.get("prompts", []))

def generate_video_variations(frames: List[Image.Image], ideas: List[Dict] = None, fps: int = 24, **kwargs) -> List[List[Image.Image]]:
    if TEST_MODE:
        results = []
        prompts = ideas or kwargs.get("prompts") or []
        for idx, _ in enumerate(prompts):
            clip_frames = []
            for f_idx, frame in enumerate(frames):
                img = frame.copy()
                draw = ImageDraw.Draw(img)
                draw.text((10, 10), f"VAR {idx+1} F{f_idx+1}", fill=(255, 0, 0))
                clip_frames.append(img)
            results.append(clip_frames)
        return results
    from .backends import get_video_backend
    backend = get_video_backend(VIDEO_BACKEND)
    return backend.video_variations(frames, ideas or kwargs.get("prompts", []), fps)