from typing import List, Tuple, Optional
from .preprocess import load_image, extract_frames
from .embed import get_clip_embedding
from .prompt_gen import generate_prompts
from .generate import generate_image_variations, generate_video_variations
from .postprocess import finalize_images, stitch_videos
from .config import VOICEOVER_ENABLED
from .tts_elevenlabs import synthesize_tts

def run_image_pipeline(image_bytes: bytes, n: int, spec: str) -> Tuple[List[bytes], List[str]]:
    image = load_image(image_bytes)
    emb = get_clip_embedding(image)
    ideas = generate_prompts(emb, spec, n)  # list[dict]
    imgs = generate_image_variations(image, ideas)
    return finalize_images(imgs, basename="image_variation")

def run_video_pipeline(video_bytes: bytes, n: int, spec: str) -> Tuple[List[bytes], List[str]]:
    frames, fps_src = extract_frames(video_bytes)
    emb = get_clip_embedding(frames[0] if frames else None)
    ideas = generate_prompts(emb, spec, n)  # list[dict]
    clips = generate_video_variations(frames, ideas, fps=fps_src)
    audio_paths: Optional[List[Optional[str]]] = None
    if VOICEOVER_ENABLED:
        # naive: synthesize per-idea using its copy text (or spec)
        audio_paths = []
        for idea in ideas:
            text = idea.get("copy") or spec
            audio_paths.append(synthesize_tts(text))
    return stitch_videos(clips, fps=fps_src, basename="video_variation", audio_paths=audio_paths)
