**Neuroad**

1. Our current website: neuroad.vip 
2. To make changes, you may start a new branch, edit there, and push to the main branch; alternatively, you may edit the main branch locally and push to the remote main branch. 
3. Try to keep limited information about how we code on the landing page when one clicks "View Page Source." 
